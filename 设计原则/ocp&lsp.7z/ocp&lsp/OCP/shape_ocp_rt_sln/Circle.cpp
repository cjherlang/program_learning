#include"Circle.h"
#include<iostream>
#include<typeinfo>
#include"Shape.h"
#include"Square.h"

void Circle::Draw() const
{
    std::cout<<"this is a Circle"<<std::endl;
}

bool Circle::Precedes(const Shape &s) const
{
    if(dynamic_cast<const Square *>(&s))
    {
        return true;
    }
    else
    {
        return false;
    }
}