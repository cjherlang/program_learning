#include<iostream>
#include<vector>
#include"Shape.h"
#include"Square.h"
#include"Circle.h"

void DrawAllShapes(std::vector<Shape *> &list);

int main()
{
    Square s1, s2;
    Circle c1, c2;
    
    std::vector<Shape *> list;
    list.push_back(&s2);
    list.push_back(&c2);
    list.push_back(&s1);
    list.push_back(&c1);
    
    DrawAllShapes(list);
    
    std::cout<<"It is over"<<std::endl;
    
    return 0;
}