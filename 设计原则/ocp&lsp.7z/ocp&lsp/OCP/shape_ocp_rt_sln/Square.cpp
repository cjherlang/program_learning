#include"Square.h"
#include<iostream>
#include"Shape.h"
#include"Circle.h"

void Square::Draw() const
{
    std::cout<<"this is a Square"<<std::endl;
}

bool Square::Precedes(const Shape &s) const
{
    if(dynamic_cast<const Circle *>(&s))
    {
        return false;
    }
    else
    {
        return true;
    }
}