#include"Square.h"
#include<iostream>

void Square::Draw() const
{
    std::cout<<"this is a Square"<<std::endl;
}