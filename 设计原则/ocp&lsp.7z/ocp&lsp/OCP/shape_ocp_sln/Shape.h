#ifndef SHAPE_H
#define SHAPE_H

class Shape
{
    public:
    virtual void Draw() const = 0;
};

#endif