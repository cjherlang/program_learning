#include"Circle.h"
#include<iostream>

void Circle::Draw() const
{
    std::cout<<"this is a Circle"<<std::endl;
}