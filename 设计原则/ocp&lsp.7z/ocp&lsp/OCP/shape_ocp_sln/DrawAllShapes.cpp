#include<vector>
#include"Shape.h"

void DrawAllShapes(std::vector<Shape*>&list)
{
    for(std::vector<Shape*>::iterator i = list.begin();
i != list.end(); i++)
        (*i)->Draw();
}