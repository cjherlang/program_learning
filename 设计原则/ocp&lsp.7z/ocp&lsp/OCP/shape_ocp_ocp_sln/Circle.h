#ifndef CIRCLE_H
#define CIRCLE_H

#include"Shape.h"

class Circle: public Shape
{
    public:
        virtual void Draw() const;
//        virtual bool Precedes(const Shape &) const;
};

#endif