#include"Shape.h"
#include<typeinfo>
#include<cstring>
#include<iostream>

bool Shape::Precedes(const Shape &s) const
{
    const char* thisType = typeid(*this).name();
   const char* argType = typeid(s).name();
   std::cout<<thisType<<"   "<<argType<<std::endl;
   bool done = false;
   int thisOrd = -1;
   int argOrd = -1;
   
   for(int i = 0; !done; i++)
   {
       const char *tableEntry = typeOrderTable[i];
       if(tableEntry != 0)
       {
           if(strcmp(tableEntry, thisType) == 0)
           {
               thisOrd = i;
           }
           if(strcmp(tableEntry, argType) == 0)
           {
               argOrd = i;
           }
           if( (argOrd >= 0) && (thisOrd >= 0) )
           {
               done = true;
           }
       }
       else
       {
           done = true;
       }
   }
   std::cout<<"   "<<(thisOrd < argOrd)<<std::endl;
   return thisOrd < argOrd;
}