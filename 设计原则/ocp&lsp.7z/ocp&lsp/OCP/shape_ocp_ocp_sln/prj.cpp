#include<iostream>
#include<vector>
#include<typeinfo>
#include"Shape.h"
#include"Square.h"
#include"Circle.h"

void DrawAllShapes(std::vector<Shape *> &list);

const char *Shape::typeOrderTable[] = 
{
    typeid(Circle).name(),
    typeid(Square).name(),
    0
};

int main()
{
    Square s1, s2;
    Circle c1, c2;
    
    std::vector<Shape *> list;
    list.push_back(&s2);
    list.push_back(&c2);
    list.push_back(&c1);
    list.push_back(&s1);
    
    DrawAllShapes(list);
    
    std::cout<<"It is over"<<std::endl;
    
    return 0;
}