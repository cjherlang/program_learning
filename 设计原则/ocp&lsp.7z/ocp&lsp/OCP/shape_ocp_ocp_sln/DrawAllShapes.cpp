#include<vector>
#include"Shape.h"
#include"algorithm"

template<typename P>
class Lessp
{
    public:
        bool operator() (const P p, const P q)
        {
            return (*p) < (*q);
        }
};

void DrawAllShapes(std::vector<Shape*>&list)
{
    std::vector<Shape *> orderedList = list;
    
    sort(orderedList.begin(), orderedList.end(), Lessp<Shape*>());
    
    for(std::vector<Shape*>::const_iterator i = orderedList.begin(); i != orderedList.end(); i++)
    {
        (*i)->Draw();
    }
}