#ifndef CIRCLE_H
#define CIRCLE_H

#include"Point.h"

struct Circle
{
    ShapeType itsType;
    double itsRadius;
    Point itsCenter;
};

#endif