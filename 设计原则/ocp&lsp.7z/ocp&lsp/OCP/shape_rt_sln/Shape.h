#ifndef SHAPE_H
#define SHAPE_H

enum ShapeType { circle, square };

struct Shape
{
    ShapeType itsType;
};

#endif