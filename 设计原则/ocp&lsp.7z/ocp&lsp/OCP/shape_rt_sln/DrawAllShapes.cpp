#include<stdio.h>
#include"Shape.h"
#include"Square.h"
#include"Circle.h"

typedef struct Shape *ShapePointer;

void DrawSquare(struct Square *s)
{
    printf("this is a square\n");
}

void DrawCircle(struct Circle *c)
{
    printf("this is a circle\n");
}

void DrawAllShapes(ShapePointer list[], int n)
{
    for(int i = 0; i < n; i++)
    {
        struct Shape *s = list[i];
        switch(s->itsType)
        {
            case square:
                DrawSquare((struct Square *)s);
             break;
             case circle:
                DrawCircle((struct Circle *)s);
             break;
        }
    }
}

int main()
{
    Point p = {1.0f, 1.0f};
    Square s1 = {square, 1.0f, p};
    Circle c1 = {circle, 1.0f, p};
    
    ShapePointer list[] = {(ShapePointer)&s1, (ShapePointer)&c1};
    
    DrawAllShapes(list, 2);
    
    printf("this is over\n");
    
    return 0;
}