#ifndef SQUARE_H
#define SQUARE_H

#include"Point.h"

struct Square
{
    ShapeType itsType;
    double itsSide;
    Point itsTopLeft;
};

#endif