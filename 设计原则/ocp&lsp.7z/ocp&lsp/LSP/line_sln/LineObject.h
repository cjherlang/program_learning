#ifndef GEOMETRY_LINEAR_OBJECT_H
#define GEOMETRY_LINEAR_OBJECT_H

#include "geometry/point.h"

class LinearObject
{
    public:
        Line(const Point &p1, const Point &p2);
        
        double GetSlope() const;
        double GetIntercept() const;
        
        Point GetP1() const
        {
            return itsP1;
        }
        
        Point GetP2() const
        {
            return itsP2;
        }
        
        virtual bool IsOn(const Point &) const = 0;
        
    private:
        Point itsP1;
        Point itsP2;
};
#endif

class Line : public LinearObject
{
    public:
        Line(const Point &p1, const Point &p2);
        virtual bool IsOn(const Point&) const;
};

class LineSegment : public LinearObject
{
    public:
        LinearSegment(const Point &p1, const Point &p2);
        double GetLength() const;
        virtual bool IsOn(const Point &) const;
};