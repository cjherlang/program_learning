
void g(Rectangle &r)
{
    r.SetWidth(5);
    r.SetHeight(4);
    assert(r.Area() == 20);
}

int main()
{
   return 0;
}