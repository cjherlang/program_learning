#ifndef SQUARE_H
#define SQUARE_H

class Square:public Rectangle
{
    public:
        virtual void SetWidth(double w)
        {
            Rectangle::SetWidth(w);
            Rectangle::SetHeight(w);
        }
        
        virtual void SetHeight(double h)
        {
            Rectangle::SetHeight(h);
            Rectangle::SetHeight(h);
        }
}

#endif