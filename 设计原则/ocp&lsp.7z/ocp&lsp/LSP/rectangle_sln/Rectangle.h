#ifndef RECTANGLE_H
#define RECTANGLE_H

class Rectangle
{
    public:
        void SetWidth(double w)
        {
            itsWidth = w;
        }
        
        void SetHeight(double h)
        {
            itsHeight = h;
        }
        
        double GetWidth() const
        {
            return itsWidth;
        }
        
        double GetHeight() const
        {
            return itsHeight;
        }
        
    private:
        Point itsTopLeft;
        double itsWidth;
        double itsHeight;
};

#endif