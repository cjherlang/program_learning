#ifndef PERSISTENT_SET_H
#define PERSISTENT_SET_H

#include"Set.h"

template<class T>
class PersistentSet : public Set
{
    public:
        virtual void Add(const T& t)
        {
            PersistentObject& p = dynamic_cast<PersistentObject&>(t);
            itsThirdPartyPersistentSet.Add(p);
        }
        virtual void Delete(const T&);
        virtual void IsMember(const T&) const;
};

#endif