#ifndef SET_H
#define SET_H

template<class T>
class Set
{
    public:
        virtual void Add(const T&) = 0;
        virtual void Delete(const T&) = 0;
        virtual void IsMember(const T&) const = 0;
};

#endif