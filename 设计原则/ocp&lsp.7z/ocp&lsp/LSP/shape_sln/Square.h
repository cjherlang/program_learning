#ifndef SQUARE_H
#define SQUARE_H

#include<iostream>
#include"Point.h"
#include"Shape.h"

struct Square:public Shape
{
    Square() : Shape(square)
    {
    }
    
    void Draw() const
    {
        std::cout<<"this is a Square"<<std::endl;
    }
    
    Point itsTopLeft;
    double itsSide;
};

#endif