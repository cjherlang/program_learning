#ifndef CIRCLE_H
#define CIRCLE_H

#include<iostream>
#include"Point.h"
#include"Shape.h"

struct Circle:public Shape
{
    Circle() : Shape(circle)
    {
    }

    void Draw() const
    {
        std::cout<<"this is a Circle"<<std::endl;
    }
    
    Point itsCenter;
    double itsRadius;
};

#endif