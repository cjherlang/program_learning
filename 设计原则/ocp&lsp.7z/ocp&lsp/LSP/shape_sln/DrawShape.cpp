#include"Shape.h"
#include"Circle.h"
#include"Square.h"

void DrawShape(const Shape& s)
{
    if(s.itsType == Shape::square)
    {
        static_cast<const Square&>(s).Draw();
    }
    else if(s.itsType == Shape::circle)
    {
        static_cast<const Circle&>(s).Draw();
    }
}