#include<iostream>
#include"Shape.h"
#include"Square.h"
#include"Circle.h"

void DrawShape(const Shape &s);

int main()
{
    Square s1;
    Circle c1;
    
    DrawShape(s1);
    DrawShape(c1);
    
    std::cout<<"It is over"<<std::endl;
    
    return 0;
}