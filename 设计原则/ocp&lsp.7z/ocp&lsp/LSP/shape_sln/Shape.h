#ifndef SHAPE_H
#define SHAPE_H

struct Shape
{
    enum ShapeType
    {
        square,
        circle,
    } itsType;
    
    Shape(ShapeType t) : itsType(t)
    {
    }
};

#endif