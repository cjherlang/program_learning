﻿#ifndef __THREAD_POOL_H__
#define __THREAD_POOL_H__

#include <thread>
#include <memory>
#include "blocking_queue.h"

class SimpleThreadTask
{
public:
    virtual ~Task()
    {
    }

    virtual void Run() = 0;
};

class SimpleThreadPool
{
public:
    ThreadPool(std::size_t thread_count) : thread_count_(thread_count)
    {
        for (std::size_t i = 0; i < thread_count_; ++i) {
            thread_vector_.push_back(std::thread(&ThreadPool::ThreadFun, this));
        }
    }

    void AddTask(const std::shared_ptr<Task>& task)
    {
        task_queue_.Push(task);
    }
private:
    void ThreadFun()
    {
        std::shared_ptr<SimpleThreadTask> task;
        while (true) {
            task_queue_.Pop(task);
            task->Run();
        }
    }
private:
    std::size_t thread_count_;
    BlockingQueue<std::shared_ptr<SimpleThreadTask>> task_queue_;
    std::vector<std::thread> thread_vector_;
};

#endif
