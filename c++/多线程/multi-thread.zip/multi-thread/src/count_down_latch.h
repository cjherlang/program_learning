﻿#ifndef __COUNT_DOWN_LATCH_H__
#define __COUNT_DOWN_LATCH_H__

#include <mutex>
#include <condition_variable>

class CountDownLatch
{
public:
    CountDownLatch(int value) : value_(value)
    {
    }

    void CountDown()
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (value_ == 0) {
            return;
        }
        if (--value_ == 0) {
            cond_.notify_all();
        }
    }

    void Wait()
    {
        std::unique_lock<std::mutex> lock(mutex_);
        while (value_ > 0) {
            cond_.wait(lock);
        }
    }
private:
    volatile int value_;
    std::mutex mutex_;
    std::condition_variable cond_;
};

#endif
