﻿#ifndef __THREAD_POOL_H__
#define __THREAD_POOL_H__

#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <memory>

//任务接口
class Task
{
public:
    virtual ~Task()
    {
    }

    virtual void Run() = 0;
};

class ThreadPool
{
public:
    ThreadPool(std::size_t thread_count, std::size_t max_task_count = 0) :
        thread_count_(thread_count),
        max_task_count_(max_task_count)
    {
        running_ = false;
    }

    ~ThreadPool()
    {
        this->Stop();
    }

    void Start()
    {
        running_ = true;
        for (std::size_t i = 0; i < thread_count_; ++i) {
            thread_vector_.push_back(std::thread(&ThreadPool::ThreadFun, this));
        }
    }

    void Stop()
    {
        running_ = false;
        not_empty_cond_.notify_all();
        for (std::thread& thread : thread_vector_) {
            thread.join();
        }
        thread_vector_.clear();
    }

    void AddTask(const std::shared_ptr<Task>& task)
    {
        std::unique_lock<std::mutex> lock(queue_mutex_);
        while (max_task_count_ > 0 && task_queue_.size() >= max_task_count_) {
            not_full_cond_.wait(lock);
        }
        task_queue_.push(task);
        not_empty_cond_.notify_one();
    }
private:
    void ThreadFun()
    {
        while (running_) {
            std::shared_ptr<Task> task = GetTask();
            if (task != NULL) {
                task->Run();
            }
        }
    }
private:
    std::shared_ptr<Task> GetTask()
    {
        std::unique_lock<std::mutex> lock(queue_mutex_);
        while (running_ && task_queue_.size() == 0) {
            not_empty_cond_.wait(lock);
        }

        if (running_ && task_queue_.size() > 0) {
            std::shared_ptr<Task> task = task_queue_.front();
            task_queue_.pop();
            return task;
        } else {   //调用了Stop()后会走这里
            return std::shared_ptr<Task>();
        }
    }
private:
    std::size_t thread_count_;    //线程数目
    std::size_t max_task_count_;  //任务队列最大容量
    std::vector<std::thread> thread_vector_;
    std::queue<std::shared_ptr<Task>> task_queue_;
    volatile bool running_;  //是否正在工作
    std::mutex queue_mutex_;
    std::condition_variable not_full_cond_;   //等待任务队列变为非满状态
    std::condition_variable not_empty_cond_;  //等待任务队列变为非空状态
};

#endif
