﻿#ifndef __BLOCKING_QUEUE_H__
#define __BLOCKING_QUEUE_H__

#include <queue>
#include <mutex>
#include <condition_variable>

template <typename T>
class BlockingQueue
{
public:
    BlockingQueue(std::size_t max_size = 0) :
        max_size_(max_size)
    {
    }

    void Push(const T& t)
    {
        std::unique_lock<std::mutex> lock(mutex_);
        while (max_size_ > 0 && queue_.size() >= max_size_) {   //可否修改为 if ?
            not_full_cond_.wait(lock);
        }
        queue_.push(t);
        //not_empty_cond_.notify_one();

        //可否修改为 当队列从 空=>非空 时才 notify ?
        if (queue_.size() == 1) {
            not_empty_cond_.notify_one();
        }
    }

    void Pop(T& t)
    {
        std::unique_lock<std::mutex> lock(mutex_);
        while (queue_.empty()) {
            not_empty_cond_.wait(lock);
        }
        t = queue_.front();
        queue_.pop();
        if (max_size_ > 0) {
            not_full_cond_.notify_one();
        }
    }
private:
    std::size_t max_size_;   //队列的最大容量，0表示无限容量
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable not_full_cond_;   //等待队列变成非满状态
    std::condition_variable not_empty_cond_;  //等待队列变成非空状态
};

#endif
