#include <iostream>
#include <thread>
#include "count_down_latch.h"

bool InitA()
{
    std::cout << "InitA" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5));
    std::cout << "InitA over" << std::endl;
    return true;
}

bool InitB()
{
    std::cout << "InitB" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5));
    std::cout << "InitB over" << std::endl;
    return true;
}

bool InitC()
{
    std::cout << "InitC" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5));
    std::cout << "InitC over" << std::endl;
    return true;
}

typedef std::function<bool(void)> InitFunc;

int main()
{
    CountDownLatch count_down_latch(2);
    bool init_success = true;

    std::function<void(const InitFunc&)> init_func_wrapper = [&count_down_latch, &init_success](const InitFunc& func) {
        if (func() == false) {
            init_success = false;
        }
        count_down_latch.CountDown();
    };

    std::thread(init_func_wrapper, InitA).detach();
    std::thread(init_func_wrapper, InitB).detach();

    count_down_latch.Wait();
    InitC();

    if (init_success) {
        std::cout << "init success" << std::endl;
    } else {
        std::cout << "init failed" << std::endl;
    }

    return 0;
}
