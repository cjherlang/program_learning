﻿#include <iostream>
#include <thread>

void NonMemberFun(int arg1, int arg2)
{
    std::cout << "NonMemberFun, arg1:" << arg1 << ", args:" << arg2 << std::endl;
}

class Test
{
public:
    static void StaticMemberFun(int arg1, int arg2)
    {
        std::cout << "StaticMemberFun, arg1:" << arg1 << ", args:" << arg2 << std::endl;
    }

    void MemberFun(int arg1, int arg2)
    {
        std::cout << "StaticMemberFun, arg1:" << arg1 << ", args:" << arg2 << std::endl;
    }

    void operator()(int arg1, int arg2)
    {
        std::cout << "operator(), arg1:" << arg1 << ", args:" << arg2 << std::endl;
    }
};

int main()
{
    std::thread t1(NonMemberFun, 1, 1);

    std::thread t2(&Test::StaticMemberFun, 2, 2);

    Test test;
    std::thread t3(&Test::MemberFun, &test, 3, 3);

    std::thread t4(test, 4, 4);

    std::thread t5([](int arg1, int arg2){
            std::cout << "lamda, arg1:" << arg1 << ", args:" << arg2 << std::endl;
            },
            5, 5);

    t1.join();
    t2.join();
    t3.join();
    t4.join();
    t5.join();

    return 0;
}
