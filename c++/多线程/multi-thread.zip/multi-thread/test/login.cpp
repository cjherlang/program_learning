#include <iostream>
#include <memory>
#include <sstream>
#include <cassert>
#include "thread_pool.h"
#include "blocking_queue.h"

class LoginTask : public Task, public std::enable_shared_from_this<LoginTask>
{
public:
    LoginTask(const std::string& access_token, BlockingQueue<std::shared_ptr<LoginTask>>& finish_queue) :
        access_token_(access_token),
        finish_queue_(finish_queue)
    {
    }

    virtual void Run() override
    {
        std::cout << "thread " << std::this_thread::get_id() << " exec login task: " << access_token_ << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(rand() % 2 + 1));  //随机sleep一段时间,用来模拟登录验证的过程
        finish_queue_.Push(this->shared_from_this());
    }

    void ShowResult()
    {
        std::cout << "login success: " << access_token_ << std::endl;
    }
private:
    std::string access_token_;
    BlockingQueue<std::shared_ptr<LoginTask>>& finish_queue_;
};

int main(int argc, char* argv[])
{
    if (argc != 3) {
        std::cerr << "invalid parameter, " << "usage: " << argv[0] << " <task-count> <pool-size>" << std::endl;
        return 1;
    }
    int task_count = atoi(argv[1]);
    int pool_size = atoi(argv[2]);
    assert(task_count > 0 && pool_size > 0);

    ThreadPool thread_pool(pool_size, 0);   //不限制task的数量
    thread_pool.Start();

    BlockingQueue<std::shared_ptr<LoginTask>> finish_queue;
    for (int i = 0; i < task_count; ++i) {
        std::ostringstream oss;
        oss << "access-token-" << i;
        thread_pool.AddTask(std::shared_ptr<LoginTask>(new LoginTask(oss.str(), finish_queue)));
    }

    for (int i = 0; i < task_count; ++i) {
        std::shared_ptr<LoginTask> task;
        finish_queue.Pop(task);
        task->ShowResult();
    }

    thread_pool.Stop();

    return 0;
}
