#include <iostream>
#include <thread>
#include <cassert>
#include "blocking_queue.h"

int main(int argc, char* argv[])
{
    if (argc != 3) {
        std::cerr << "invalid parameter, " << "usage: " << argv[0] << " <data-count> <consumer-count>" << std::endl;
        return 1;
    }
    int data_count = atoi(argv[1]);
    int consumer_count = atoi(argv[2]);
    assert(data_count > 0 && consumer_count > 0);

    BlockingQueue<int> blocking_queue;

    //创建消费者线程
    for (int i = 0; i < consumer_count; ++i) {
        std::thread consumer_thread([&blocking_queue] {
            int value = 0;
            while (true) {
                blocking_queue.Pop(value);
                std::cout << "thread " << std::this_thread::get_id() << " get value: " << value << std::endl;
                std::this_thread::sleep_for(std::chrono::seconds(1));
            }
        });
        consumer_thread.detach();
    }

    //生产数据
    for (int i = 0; i < data_count; ++i) {
        blocking_queue.Push(i);
        if (i % 5 == 0) {
            std::this_thread::sleep_for(std::chrono::seconds(3));
        }
    }

    return 0;
}
