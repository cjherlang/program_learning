#include <iostream>
#include <memory>
#include "thread_pool.h"
#include "blocking_queue.h"

class CalculateTask : public Task, public std::enable_shared_from_this<CalculateTask>
{
public:
    CalculateTask(int a, int b, BlockingQueue<std::shared_ptr<CalculateTask>>& finish_queue) :
        a_(a),
        b_(b),
        finish_queue_(finish_queue)
    {
    }

    virtual void Run() override
    {
        std::this_thread::sleep_for(std::chrono::seconds(rand() % 2 + 1));
        result_ = a_ + b_;
        finish_queue_.Push(this->shared_from_this());
    }

    void ShowResult()
    {
        std::cout << a_ << " + " << b_ << " = " << result_ << std::endl;
    }
private:
    int a_;
    int b_;
    int result_;
    BlockingQueue<std::shared_ptr<CalculateTask>>& finish_queue_;
};

int main()
{
    ThreadPool thread_pool(5, 0);
    thread_pool.Start();
    const int TASK_COUNT = 10;
    BlockingQueue<std::shared_ptr<CalculateTask>> finish_queue;
    for (int i = 0; i < TASK_COUNT; ++i) {
        thread_pool.AddTask(std::shared_ptr<CalculateTask>(new CalculateTask(rand() % 10000, rand() % 10000, finish_queue)));
    }
    for (int i = 0; i < TASK_COUNT; ++i) {
        std::shared_ptr<CalculateTask> task;
        finish_queue.Pop(task);
        task->ShowResult();
    }
    thread_pool.Stop();

    return 0;
}
