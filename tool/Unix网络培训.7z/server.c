#include<sys/socket.h>//socket()
#include<netinet/in.h>//sockaddr_in
#include<stdio.h>//perror()
#include<unistd.h>//fork()
#include<stdlib.h>
#include<errno.h>//errno, EINTR
#include<string.h>//strlen()

#define PORT 7788
#define MAX_LINE 1000


void server_read(int sockfd);

int main(int argc, char *argv[])
{
    int listenfd, connfd;
    struct sockaddr_in cliaddr, servaddr;
    pid_t childpid;
    socklen_t clilen;

    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket error\n");
    }
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);
    if (bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1)
    {
        perror("bind error");
        exit(EXIT_FAILURE);
    }
    printf("bind OK\n");
    if (listen(listenfd, 5) == -1)
    {
        perror("listen error");
    }
    printf("now listening \n");
    for (;;)
    {
        clilen = sizeof(cliaddr);
        connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &clilen);
        if (connfd == -1)
        {
            perror("accept error\n");
        }
        printf("now receive a new connect!!\n");
        if ((childpid == fork())==0)//child
        {
            close(listenfd);
            server_read(connfd);
            exit(0);
        }
    }
    close(connfd);
}

void
server_read(int sockfd)
{
    unsigned int n;
    char recebuf[MAX_LINE];

    bzero(recebuf, MAX_LINE);
again:
    while ((n = read(sockfd, recebuf, MAX_LINE - 1)) > 0)
    {
        //fputs(recebuf, stdout);
        recebuf[n] = '\0';
        printf("server receive: %s\n", recebuf);
        write(sockfd, recebuf, strlen(recebuf));
        printf("server write: %s\n", recebuf);
    }
    if (n < 0 && errno == EINTR)
    {
        goto again;
    }
    else if (n < 0)
    {
        perror("read or write error");
    }
}
