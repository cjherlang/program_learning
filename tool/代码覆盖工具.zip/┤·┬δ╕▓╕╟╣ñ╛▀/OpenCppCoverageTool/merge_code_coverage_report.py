# -*- coding:utf-8 -*-

import os
from datetime import datetime

if __name__ == "__main__":
    with open("code_coverage_time.txt", 'r') as f:
        str = ""
        for line in f:
            str += "--input_coverage="+line[:-1]+".cov "

        print ("OpenCppCoverage \
        --sources=F:\\myproject\\game_lhj_server\\ \
        %s \
        -- F:\\myproject\\game_lhj_server\\target\\bin\\gameserver_main.exe" % str)
        
        os.system("OpenCppCoverage \
        --sources=F:\\myproject\\game_lhj_server\\ \
        %s \
        -- F:\\myproject\\game_lhj_server\\target\\bin\\gameserver_main.exe" % str)
        
