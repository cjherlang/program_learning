# -*- coding:utf-8 -*-

import os

if __name__ == "__main__":
    with open("code_coverage_time.txt", 'r') as f:
        str = ""
        for line in f:
            os.remove("%s.cov" % line[:-1])

    os.remove("code_coverage_time.txt")