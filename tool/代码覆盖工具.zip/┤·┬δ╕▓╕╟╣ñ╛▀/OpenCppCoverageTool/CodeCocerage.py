# -*- coding:utf-8 -*-

import os
from datetime import datetime

if __name__ == "__main__":
    now = datetime.now().strftime("%Y%m%d%H%M%S")
    with open("code_coverage_time.txt", 'a') as f:
        f.write(now);
        f.write("\n")
    
    os.system("OpenCppCoverage \
        --sources=F:\\myproject\\game_lhj_server\\ \
        --export_type=binary:%s.cov \
        -- F:\\myproject\\game_lhj_server\\target\\bin\\gameserver_main.exe" % now)
